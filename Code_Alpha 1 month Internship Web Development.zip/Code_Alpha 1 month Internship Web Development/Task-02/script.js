document.addEventListener("DOMContentLoaded", () => {
    const todoForm = document.getElementById("todoForm");
    const taskInput = document.getElementById("taskInput");
    const todoList = document.getElementById("todoList");

    // Add new task
    todoForm.addEventListener("submit", (e) => {
        e.preventDefault(); // Prevent form submission

        const taskText = taskInput.value.trim();

        if (taskText !== "") {
            addTaskToList(taskText);
            taskInput.value = ""; // Clear input field
        }
    });

    // Function to add task to the list
    function addTaskToList(taskText) {
        const li = document.createElement("li");
        li.innerHTML = `
            <span>${taskText}</span>
            <button class="delete">Delete</button>
        `;

        // Add event listener for delete button
        li.querySelector(".delete").addEventListener("click", () => {
            li.remove();
        });

        todoList.appendChild(li);
    }
});
