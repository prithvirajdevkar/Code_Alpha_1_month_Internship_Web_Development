document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signupForm");
    const welcomeMessage = document.getElementById("welcomeMessage");

    signupForm.addEventListener("submit", (e) => {
        e.preventDefault(); // Prevent form submission

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        // Validate form inputs
        if (!name || !email || password.length < 6) {
            alert("Please fill out all fields correctly.");
            return;
        }

        // Display a welcome message
        welcomeMessage.textContent = `Welcome, ${name}! Your account has been created successfully.`;
        welcomeMessage.style.display = "block";

        // Clear the form
        signupForm.reset();
    });
});
